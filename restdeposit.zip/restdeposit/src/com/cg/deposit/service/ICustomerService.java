package com.cg.deposit.service;

public interface ICustomerService {
	
	public double deposit(int id, double amount);

}
