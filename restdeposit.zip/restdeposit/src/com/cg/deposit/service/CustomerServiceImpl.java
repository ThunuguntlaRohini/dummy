package com.cg.deposit.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.deposit.dao.ICustomerDao;

@Service("service")
@Transactional
public class CustomerServiceImpl implements ICustomerService {
	@Autowired
	private ICustomerDao dao;

	@Override
	public double deposit(int id, double amount) {

		return dao.deposit(id, amount);
	}

}
