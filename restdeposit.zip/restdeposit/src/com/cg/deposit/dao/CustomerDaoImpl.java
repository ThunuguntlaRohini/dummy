package com.cg.deposit.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.deposit.bean.Customer;


@Repository("dao")
@Transactional
public class CustomerDaoImpl implements ICustomerDao {

	@PersistenceContext
	EntityManager em;
@Transactional
	public  double deposit(int id, double amount) {
		
	double balance=0;
	if(amount>0) 
	{
		Customer customer=em.find(Customer.class, id);
		balance=customer.getBalance()+amount;
		customer.setBalance(balance);	
		em.merge(customer);
	}
		return balance;
		
	}

}
