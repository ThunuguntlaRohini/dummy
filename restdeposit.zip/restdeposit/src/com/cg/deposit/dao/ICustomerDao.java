package com.cg.deposit.dao;

public interface ICustomerDao {
	public double deposit(int id, double amount);

}
