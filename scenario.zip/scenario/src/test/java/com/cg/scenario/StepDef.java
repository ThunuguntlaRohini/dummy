package com.cg.scenario;

import java.util.List;
import java.util.regex.Pattern;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {

	WebDriver driver = null;
	Web factory = null;

	@Given("^user is on login page$")
	public void user_is_on_login_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\\\Users\\\\ROHINI\\\\Documents\\\\ROHINI\\\\chromedriver.exe");
		driver = new ChromeDriver();
		factory = new Web(driver);
		driver.get("file:///C:/Users/ROHINI/Desktop/testt.html");
	}
	@Then("^display title$")
	public void display_title()  {
		String title=driver.getTitle();
		if(title.equals("Registration form")) {
			System.out.print("matched");
		}else {
			System.out.print("not matched");
		}
	System.out.println(title);
	driver.close();
	}

	
	@Given("^user is on registration page$")
	public void user_is_on_registration_page() throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\\\Users\\\\ROHINI\\\\Documents\\\\ROHINI\\\\chromedriver.exe");
		driver = new ChromeDriver();
		factory = new Web(driver);
		driver.get("file:///C:/Users/ROHINI/Desktop/testt.html");
	}

	@When("^user enters (\\d+)$")
	public void user_enters(Integer pno) throws Exception {
		factory.setName("sowjanya");
		factory.setMobileNumber(pno.toString());
		factory.setButton();
	}

	@Then("^display appropriate message$")
	public void display_appropriate_message() throws Exception {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		System.out.println("not matched " + alertMessage);
		driver.close();
		
	}


	
	@When("^user enters name$")
	public void user_enters_name(DataTable name) throws Throwable {

		List<String> list = name.asList(String.class);
		String data = null;
		for (String dataTemp : list) {
			data = dataTemp;
			factory.getName().clear();
			factory.setName(dataTemp);
			Thread.sleep(1000);
			factory.setButton();

			if (Pattern.matches("^[A-Za-z]{3,15}$", data)) {
				System.out.println("Matching ");
				
			}else {
				System.out.print("not matched");
			}
			String alertMessage = driver.switchTo().alert().getText();
			Thread.sleep(1000);
			driver.switchTo().alert().accept();
			System.out.println(alertMessage);
			
		}	factory.setButton();
	}
	
	@When("^user leaves gender$")
	public void user_leaves_gender() throws Exception  {
	   factory.setName("sowjanya");
	   factory.setMobileNumber("9032974524");
	   factory.setEmail("fghhohi@gmail.com");
	   factory.setAddress("mndgnghf");
	   factory.setButton();
	   
	}
	
	@When("^user leaves course$")
	public void user_leaves_course() throws Throwable {
		 factory.setName("sowjanya");
		   factory.setMobileNumber("9032974524");
		   factory.setEmail("fghhohi@gmail.com");
		   factory.setFemale();
		   factory.setAddress("mndgnghf");
		   Thread.sleep(2000);
		   factory.setCity("rjpt");
		   factory.setButton();
	}

	@When("^user leaves city$")
	public void user_leaves_city() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 factory.setName("sowjanya");
		   factory.setMobileNumber("9032974524");
		   factory.setEmail("fghhohi@gmail.com");
		   factory.setFemale();
		   factory.setAddress("mndgnghf");
		   factory.setCourse("spring");
		   Thread.sleep(2000);
		   factory.setCourse("c");
		   Thread.sleep(2000);
		   factory.setButton();
	}

	@When("^user entered all details$")
	public void user_entered_all_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 factory.setName("sowjanya");
		   factory.setMobileNumber("9032974524");
		   factory.setEmail("fghhohi@gmail.com");
		   factory.setFemale();
		   factory.setAddress("mndgnghf");
		   factory.setCourse("spring");
		   Thread.sleep(2000);
		   factory.setCourse("c");
		   Thread.sleep(2000);
		   factory.setCity("rjpt");
		   factory.setButton();
	}

	@Then("^display success page$")
	public void display_success_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    driver.close();
	}
	
	
	
	}


