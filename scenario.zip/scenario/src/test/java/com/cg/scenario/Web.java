package com.cg.scenario;

import java.util.List;
import org.openqa.selenium.support.ui.Select;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Web {

	WebDriver d;

	public Web(WebDriver driver) {
		super();
		this.d = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(name = "name")
	@CacheLookup
	WebElement name;

	@FindBy(name = "mobilenumber")
	@CacheLookup
	WebElement mobileNumber;

	@FindBy(name = "email")
	@CacheLookup
	WebElement email;

	@FindBy(name = "address")
	@CacheLookup
	WebElement address;

	@FindBy(name = "submit")
	@CacheLookup
	WebElement button;

	@FindBy(id = "1")
	@CacheLookup
	WebElement male;

	@FindBy(id = "2")
	@CacheLookup
	WebElement female;

	@FindBy(name = "course")
	@CacheLookup
	List<WebElement> course;

	@FindBy(name = "city")
	@CacheLookup
	WebElement city;

	public List<WebElement> getCourse() {
		return course;
	}

	public void setCourse(String course1) {
		int size = course.size();
		for (int i = 0; i < size; i++) {
			String val = course.get(i).getAttribute("value");
			if (val.equalsIgnoreCase(course1)) {

				course.get(i).click();
			}
		}
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String city1) {
		Select select = new Select(city);
		select.selectByVisibleText(city1);

	}

	public WebElement getMale() {
		return male;
	}

	public void setMale() {
		this.male.click();
	}

	public WebElement getFemale() {
		return female;
	}

	public void setFemale() {
		this.female.click();
	}

	public WebElement getButton() {
		return button;
	}

	public void setButton() {
		button.click();
	}

	public WebElement getName() {
		return name;
	}

	public void setName(String name1) {
		name.sendKeys(name1);
	}

	public WebElement getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber1) {
		mobileNumber.sendKeys(mobileNumber1);
		;
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email1) {
		email.sendKeys(email1);
	}

	public WebElement getAddress() {
		return address;
	}

	public void setAddress(String address1) {
		address.sendKeys(address1);
	}

}
