package com.cg.hotel.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.hotel.dto.HotelDetails;

@Repository("dao")
public class HotelDaoImpl implements IHotelDao {
	@PersistenceContext
	EntityManager em;

	@Override
	public List<HotelDetails> displayHotelDetails() {
		TypedQuery<HotelDetails> query = em.createQuery("from HotelDetails",
				HotelDetails.class);
		List<HotelDetails> list = query.getResultList();
		return list;
	}

	@Override
	public String searchHotelName() {
		HotelDetails hotel =em.find(HotelDetails.class, 3);
		return hotel.getName();
	}

	
}
