package com.cg.hotel.dao;

import java.util.List;

import com.cg.hotel.dto.HotelDetails;

public interface IHotelDao {
	List<HotelDetails> displayHotelDetails();

	String searchHotelName();


}
