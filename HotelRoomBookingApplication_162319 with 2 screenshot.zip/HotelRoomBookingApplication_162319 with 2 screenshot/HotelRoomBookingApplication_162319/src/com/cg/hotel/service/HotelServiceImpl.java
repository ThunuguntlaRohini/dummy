package com.cg.hotel.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.hotel.dao.IHotelDao;
import com.cg.hotel.dto.HotelDetails;
@Service("service")
@Transactional
public class HotelServiceImpl  implements IHotelService{
@Autowired
	private IHotelDao dao;
	@Override
	public List<HotelDetails> displayHotelDetails() {

		return dao.displayHotelDetails();
	}
	@Override
	public String searchHotelName() {

		return dao.searchHotelName();
	}
	
}
