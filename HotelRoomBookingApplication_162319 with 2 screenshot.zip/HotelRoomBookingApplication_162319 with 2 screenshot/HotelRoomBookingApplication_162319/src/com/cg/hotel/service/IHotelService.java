package com.cg.hotel.service;

import java.util.List;

import com.cg.hotel.dto.HotelDetails;

public interface IHotelService {

	List<HotelDetails> displayHotelDetails();

	String searchHotelName();


}
