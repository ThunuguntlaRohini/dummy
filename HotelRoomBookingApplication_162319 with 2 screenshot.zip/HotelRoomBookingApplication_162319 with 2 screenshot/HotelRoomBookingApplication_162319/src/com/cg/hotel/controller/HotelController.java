package com.cg.hotel.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.hotel.dto.HotelDetails;
import com.cg.hotel.service.IHotelService;

@Controller
public class HotelController {

	@Autowired
	private IHotelService service;

	@RequestMapping(value = "display", method = RequestMethod.GET)
	public String displayHotelDetails(Model model, @ModelAttribute("my") HotelDetails hotel) {

		List<HotelDetails> list = service.displayHotelDetails();
		model.addAttribute("HotelDetails", list);
		return "HotelDetails";

	}

	@RequestMapping(value = "booking", method = RequestMethod.GET)
	public String sucess(Model model) {
		String name = service.searchHotelName();
		model.addAttribute("name", name);
		return "BookingConfirmation";
	}

}
